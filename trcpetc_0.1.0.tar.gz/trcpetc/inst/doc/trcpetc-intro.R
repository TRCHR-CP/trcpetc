## ----setup, include=FALSE-----------------------------------------------------
library(trcpetc)
library(knitr)
library(kableExtra)
library(dplyr)
library(ggplot2)
knitr::opts_chunk$set(echo = TRUE)

## ----cache = FALSE, echo = FALSE----------------------------------------------
# Here we should load the data
data(cardio_data)

## ----eval=FALSE---------------------------------------------------------------
# devtools::install("/path/to/TRCPETC", upgrade = "never", build_vignettes = TRUE)

## ----eval=FALSE---------------------------------------------------------------
# remove.packages("trcpetc")
# devtools::install("/path/to/TRCPETC", upgrade = "never", build_vignettes = TRUE)

## ----cars---------------------------------------------------------------------
# Without factor_order
t1 <- cardio_data %>% select(SurgeryType) %>% table_one()
kable_table_one(t1)


## -----------------------------------------------------------------------------
# With factor_order
t1 <- cardio_data %>% 
  mutate(SurgeryType = factor_order(SurgeryType)) %>% select(SurgeryType) %>% table_one()
kable_table_one(t1)


## -----------------------------------------------------------------------------
# List of Comorbidities columns 

Comorbidities  <- cardio_data %>% select(Diabetes:NoComorbidities) %>% names()

## Without checkbox question (Assuming missing all questions is FALSE)
t1 <- cardio_data %>% select(Comorbidities) %>% 
   table_one()
kable_table_one(t1)

## -----------------------------------------------------------------------------
# Example with one checkbox question (Assumes missing all questions is missing)

t1 <- cardio_data %>% select(Comorbidities) %>% 
  check_box_convert(check_box_cols = Comorbidities,title = "Comorbidities¹")  %>% 
  table_one(Check_box = Comorbidities,
            Check_box_title = "Comorbidities¹") 
kable_table_one(t1) %>%
  kableExtra::footnote(
    general = "¹Patients could present with more than one comorbidity, totals may not sum to 100%.",
    general_title = "",
    footnote_as_chunk = TRUE
  ) 


## -----------------------------------------------------------------------------
## Example with two different checkbox questions
Comorbidities1  <- cardio_data %>% select(Diabetes:COPD) %>% names()
Comorbidities2  <- cardio_data %>% select(CKD:CAD) %>% names()

t1 <- cardio_data %>% select(Comorbidities1,Comorbidities2) %>% 
  check_box_convert(check_box_cols = Comorbidities1,title = "Comorbidities1¹")  %>% 
  check_box_convert(check_box_cols = Comorbidities2,title = "Comorbidities2¹")  %>% 
  table_one(Check_box = Comorbidities,
            Check_box_title = c("Comorbidities1¹","Comorbidities2¹"))

kable_table_one(t1) %>%
  kableExtra::footnote(
    general = "¹Patients could present with more than one comorbidity, totals may not sum to 100%.",
    general_title = "",
    footnote_as_chunk = TRUE
  ) 


## -----------------------------------------------------------------------------
Comorbidities  <- cardio_data %>% select(Diabetes:NoComorbidities) %>% names()

work_d <- cardio_data %>% 
  mutate(SurgeryType = factor_order(SurgeryType)) %>% 
  check_box_convert(check_box_cols = Comorbidities,title = "Comorbidities¹") 



t1 <- table_one(df = work_d , 
                group = Sex,  
                datadic = cardio_data_dictionary %>% 
                  rbind(data.frame("VariableName" = "Comorbidities¹", "Label" ="Comorbidities¹", "Description"= "All Comorbidities")),
                var_name = VariableName, 
                var_desp = Label,
                # caption =  "Summary table overall and stratified by sex",
                include_overall = "all",
                Check_box = Comorbidities,
                Check_box_title = "Comorbidities¹") 

kable_table_one(t1, caption = "Summary table overall and stratified by sex") %>%
  kableExtra::footnote(
    general = "¹Patients could present with more than one comorbidity, totals may not sum to 100%.",
    general_title = "",
    footnote_as_chunk = TRUE) 


## -----------------------------------------------------------------------------
## For survival
survival_data <-  construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = DeathDate,
                           end_dt = LastVisitDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)

# For competing risks
cmp_risk_data <- construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = TransplantDate,
                           end_dt = LastVisitDate,
                           death_dt = DeathDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)


## -----------------------------------------------------------------------------
## For survival
survival_data <-  construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = DeathDate,
                           end_dt = LastVisitDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)

KM <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time) 
KM_Sex <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time,group = Sex) 



# For competing risks
cmp_risk_data <- construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = TransplantDate,
                           end_dt = LastVisitDate,
                           death_dt = DeathDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)

CIF <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time) 
CIF_Sex <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time,group = Sex) 

## ----fig.width=6, fig.height=6------------------------------------------------
## Example without a covariate
## to show proportion of deceased patients, you can set failure_fun = TRUE
survival_data <-  construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = DeathDate,
                           end_dt = LastVisitDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)

KM <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time) 
summarize_km(KM, failure_fun = FALSE, times = seq(0, 24, by = 3), overall_label = "All patients",time_lab = "Time since surgery (months)",caption = "Overall Survival for all patients")



## -----------------------------------------------------------------------------
## Example with a covariate
## to show proportion of deceased patients, you can set failure_fun = TRUE
KM_Sex <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time,group = Sex) 
summarize_km(KM_Sex, failure_fun = FALSE, times = seq(0, 24, by = 3), overall_label = "All patients",time_lab = "Time since surgery (months)",caption = "Overall Survival by sex")




## -----------------------------------------------------------------------------
cmp_risk_data <- construct_surv_cmprisk_var(cardio_data,
                           patid = PatientID,
                           idx_dt = SurgeryDate,
                           evt_dt = TransplantDate,
                           end_dt = LastVisitDate,
                           death_dt = DeathDate,
                           append = TRUE,
                           units = "months",
                           adm_cnr_time = 24)

CIF <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time) 

## Presenting one event for all patients 
  summarize_cif(CIF,times = seq(0, 24, by = 3), time_lab = "Time since surgery (months)",evt_type = 1,caption = "Time to transplant for all patients",
  evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"))
  

## -----------------------------------------------------------------------------
## Presenting all events for all patients 
    summarize_cif(CIF, times = seq(0, 24, by = 3), time_lab = "Time since surgery (months)", caption = "Time to transplant for all patients",
  evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"))


## -----------------------------------------------------------------------------
CIF_Sex <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time,group = Sex) 

## Presenting only the events by a covariate

  summarize_cif(CIF_Sex, times = seq(0, 24, by = 3), time_lab = "Time since surgery (months)",evt_type = 1,caption = "Time to transplant by sex",
  evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"))


## -----------------------------------------------------------------------------
## Presenting all events by a covariate 


  summarize_cif(CIF_Sex, times = seq(0, 24, by = 3), time_lab = "Time since surgery (months)",caption = "Time to transplant by sex",
 evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"))



## ----fig.width=6, fig.height=6------------------------------------------------
## All patients 
survival_data <-  construct_surv_cmprisk_var(cardio_data,
                                            patid = PatientID,
                                            idx_dt = SurgeryDate,
                                             evt_dt = DeathDate,
                                            end_dt = LastVisitDate,
                                             append = TRUE,
                                             units = "months",
                                            adm_cnr_time = 24)

 KM <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time)
 show_surv(KM, pvalue_pos = "bottomleft",add_legend = TRUE,x_break = seq(0,24,by=3),atrisk_init_pos = -0.15,
           x_lab = "Time since surgery (months)") 
 

## ----fig.width=6, fig.height=6------------------------------------------------
## Stratified by a covariate
 KM_Sex <- estimate_cif_km(survival_data, evt = evt,evt_time = evt_time,group = Sex)
 show_surv(KM_Sex,pvalue_pos = "bottomleft",add_legend = TRUE,x_break = seq(0,24,by=3),atrisk_init_pos = -0.15,
           x_lab = "Time since surgery (months)") 

## ----fig.width=6, fig.height=6------------------------------------------------
## Showing all events for all patients 
cmp_risk_data <- construct_surv_cmprisk_var(cardio_data,
                                            patid = PatientID,
                                            idx_dt = SurgeryDate,
                                            evt_dt = TransplantDate,
                                            end_dt = LastVisitDate,
                                            death_dt = DeathDate,
                                            append = TRUE,
                                            units = "months",
                                            adm_cnr_time = 24)

 CIF <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time)

  show_cif(CIF,evt_type = c(0,1,2),add_legend = TRUE,x_break = seq(0,24,by=3),
           evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"),
           x_lab = "Time since surgery (months)",
           color_scheme = "manual",
           color_list = list(values= c("#33A02C", "#377EB8", "#E41A1C"))) +
  guides(
    fill  = "none",                 # ❌ remove duplicate legend
    color = guide_legend(title = NULL)  # ❌ remove "state" title
  ) +
theme(
  legend.position = "right"
)
  

## ----fig.width=6, fig.height=6------------------------------------------------
## Including a covariate and stratified by a covariate
 CIF_Sex <- estimate_cif_km(cmp_risk_data , evt = evt,evt_time = evt_time,group = Sex)

show_cif(CIF_Sex,evt_type = c(1),add_legend = FALSE,x_break = seq(0,24,by=3),
         evt_label = c('0' = "Event free", '1' = "Transplant", '2'= "Death"),
         x_lab = "Time since surgery (months)")



## ----fig.width=6, fig.height=6------------------------------------------------
## Showing all events 
cmp_risk_data <- construct_surv_cmprisk_var(cardio_data,
                                            patid = PatientID,
                                            idx_dt = SurgeryDate,
                                            evt_dt = TransplantDate,
                                            end_dt = LastVisitDate,
                                            death_dt = DeathDate,
                                            append = TRUE,
                                            units = "months",
                                            adm_cnr_time = 24)

 CIF <- estimate_cif_km(cmp_risk_data, evt = evt,evt_time = evt_time)

median_time_to_event(survfitms_obj = CIF, target_prob= 0.2,evt_type = 1, interpolate = TRUE)


## -----------------------------------------------------------------------------
CIF_Sex <- estimate_cif_km(cmp_risk_data , evt = evt,evt_time = evt_time,group = Sex)
 median_time_to_event(survfitms_obj = CIF_Sex,subgroup = "Sex=Male", target_prob= 0.2,evt_type = 1, interpolate = TRUE)

## -----------------------------------------------------------------------------
median_time_to_event(survfitms_obj = CIF_Sex,subgroup = "Sex=Female", target_prob= 0.2,evt_type = 1, interpolate = TRUE)

