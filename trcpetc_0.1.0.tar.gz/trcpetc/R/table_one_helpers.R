#' @title table_one_overall
#' @description table one with no stratifying variable
#' @keywords internal
#' @importFrom data.table :=

format_smd <- function(x) {
  if (length(x) == 0 || is.na(x)) return(NA_character_)
  formatC(x, digits = 3, format = "f")
}

continuous_smd <- function(variable, group, binary = FALSE) {
  means <- tapply(variable, group, mean, na.rm = TRUE)
  vars <- if (binary) means * (1 - means) else tapply(variable, group, stats::var, na.rm = TRUE)
  mean_diff <- outer(means, means, FUN = "-")
  pooled_var <- outer(vars, vars, FUN = "+") / 2
  smd <- mean_diff / sqrt(pooled_var)
  smd[is.na(smd) & mean_diff == 0 & pooled_var == 0] <- 0
  abs(smd[lower.tri(smd)])
}

categorical_smd <- function(tab) {
  proportions <- prop.table(tab, margin = 1)
  if (ncol(proportions) > 1) proportions <- proportions[, -1, drop = FALSE]
  covariances <- lapply(seq_len(nrow(proportions)), function(i) {
    p <- proportions[i, ]
    covariance <- -outer(p, p)
    diag(covariance) <- p * (1 - p)
    drop(covariance)
  })
  distances <- unlist(lapply(seq_len(nrow(proportions) - 1), function(i) {
    vapply((i + 1):nrow(proportions), function(j) {
      difference <- proportions[i, ] - proportions[j, ]
      pooled_covariance <- (covariances[[i]] + covariances[[j]]) / 2
      if (anyNA(difference) || anyNA(pooled_covariance)) {
        NA_real_
      } else if (all(pooled_covariance == 0)) {
        if (all(difference == 0)) 0 else NaN
      } else {
        as.numeric(sqrt(t(difference) %*% MASS::ginv(pooled_covariance) %*% difference))
      }
    }, numeric(1))
  }))
  distances
}

average_pairwise_smd <- function(smd) {
  if (length(smd) == 0) NA_real_ else mean(smd, na.rm = TRUE)
}

table_one_overall <- function(df,total = TRUE,round_to_100 = FALSE,drop.unused.levels = FALSE,overall_label = "Overall"){

  df <- df %>%
    dplyr::ungroup() %>%
    dplyr::select_if(Negate(is.character)) %>%
    dplyr::select_if(Negate(lubridate::is.Date)) %>%
    as.data.frame() %>% tibble::as_tibble()

  if(drop.unused.levels) df <- df %>% dplyr::mutate_if(is.factor, droplevels)



  num_out_lst <- if (any(sapply(df, class) %in% c("numeric", "integer"))) {
    numeric_desp(df) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::mutate(row_id= paste(variable, type, sep= "_")) %>%
      split(., .$variable)
  } else NULL

  fct_out_lst <- if (any(sapply(df, class)=="factor")) {
    factor_desp(df,round_to_100 = round_to_100,drop.unused.levels=drop.unused.levels) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::rename(type= level) %>%
      dplyr::mutate(row_id= ifelse(type!= "." & !is.na(type),
                                   paste(variable, gsub("\\ ", "_", trimws(type)), sep= "_"),
                                   variable)) %>%
      split(., .$variable)
  } else NULL

  logic_out_lst <- if (any(sapply(df, class)=="logical")) {
    logical_desp(df) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::mutate(row_id= paste0(variable, "TRUE")) %>%
      split(., .$variable)
  } else NULL

  Total_N <- if (total) {

    N <- df %>%
      dplyr::count() %>% unlist()

    list(N = data.frame(row_id = "Total_N",variable  = "Total N",type = as.character(NA), n = as.character(N),stat = as.character(N)))

  } else NULL

  out_lst <-
    Total_N %>%
    append(num_out_lst) %>%
    append(fct_out_lst) %>%
    append(logic_out_lst)

  Output <- out_lst[c("N",names(df))] %>% dplyr::bind_rows() %>% dplyr::rename(!!paste0(overall_label,"_n") := n, !!paste0(overall_label,"_stat") := stat)



  return(Output)

}

#' @title table_one_stratify
#' @description table one with a stratifying variable
#' @keywords internal
#'
table_one_stratify <- function(df,group,total = TRUE,round_to_100 = FALSE,drop.unused.levels = FALSE){

  group <- rlang::enquo(group)

  if(drop.unused.levels) df <- df  %>%  dplyr::ungroup() %>% dplyr::mutate_if(is.factor, droplevels)


  df <- df %>%
    dplyr::ungroup() %>%
    dplyr::select_if(Negate(is.character)) %>%
    dplyr::select_if(Negate(lubridate::is.Date)) %>%
    dplyr::filter(!is.na(!!group)) %>%
    dplyr::group_by(!!group)



  group_var_idx <- match(dplyr::group_vars(df), names(df))


  num_out_lst <- if (any(sapply(df[-group_var_idx], class) %in% c("numeric", "integer"))) {
    numeric_desp(df, !!group) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::mutate(row_id= paste(variable, type, sep= "_")) %>%
      split(., .$variable)
  } else NULL

  fct_out_lst <- if (any(sapply(df[-group_var_idx], class)=="factor")) {
    factor_desp(df,!!group,round_to_100 = round_to_100,drop.unused.levels=drop.unused.levels) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::rename(type= level) %>%
      dplyr::mutate(row_id= ifelse(type!= "." & !is.na(type),
                                   paste(variable, gsub("\\ ", "_", trimws(type)), sep= "_"),
                                   variable)) %>%
      split(., .$variable)
  } else NULL

  logic_out_lst <- if (any(sapply(df[-group_var_idx], class)=="logical")) {
    logical_desp(df, !!group) %>%
      tibble::rownames_to_column("row_id") %>%
      dplyr::mutate(row_id= paste0(variable, "TRUE")) %>%
      split(., .$variable)
  } else NULL

  Total_N <- if (total) {

    n_var <- df %>%
      dplyr::count(!!group) %>%
      tidyr::pivot_wider(names_from = !!group, values_from = n, values_fill = 0) %>%
      dplyr::mutate(variable = "Total N") %>%
      dplyr::select(variable, dplyr::everything())

    n_var <- n_var %>% dplyr::mutate(dplyr::across(dplyr::select_if(n_var, is.integer) %>% names(), as.character))

    list(N = dplyr::left_join(n_var, n_var, by= "variable", suffix= c("_n", "_stat")) %>%
           dplyr::mutate(row_id = "Total_N", type = as.character(NA), pval = as.character(NA), test = as.character(NA)) %>%
           dplyr::select(row_id,variable, type, dplyr::everything()) %>%
           dplyr::mutate(type= NA_character_))

  } else NULL

  out_lst <-
    Total_N %>%
    append(num_out_lst) %>%
    append(fct_out_lst) %>%
    append(logic_out_lst)

  Output <- out_lst[c("N",names(df))] %>% dplyr::bind_rows()



  return(Output)

}




# Factor desp -------------------------------------------------------------------------

#---- summarize factor variables ----
#' @title factor_desp
#'
#' @details An internal function that calculate frequencies and proportion of levels in factor/categorical variables.
#' If there are more than 1 group, then fisher exact tests are applied to assess the between-group differences.
#'
#' @param df Dataframe
#' @param group Optional grouping variable.
#' @param includeNA Logical; whether to include missing values as a level.
#' @param round_to_100 Logical; whether rounded percentages should sum to 100.
#' @param drop.unused.levels Logical; whether to remove unused factor levels.
#' @return a dataframe consisting of columns of character variables indicating the frequency and proportion of logical variables.
factor_desp <- function(df, group, includeNA = FALSE,round_to_100 = FALSE,drop.unused.levels = FALSE) {

  ##
  make_univariate_fml <- function(x, y= NULL) {
    sapply(x, function(x){
      if (is.null(y)) stats::formula(paste0("~", x)) else stats::formula(paste0(y, "~", x))
    })
  }

  make_bivariate_fml <- function(x, z, y= NULL) {
    sapply(x, function(x){
      if (is.null(y)) stats::formula(paste0("~", x, " + ", z)) else stats::formula(paste0(y, "~", x, " + ", z))
    })
  }

  output_one_way_tbl <- function(freq, pct_digits = 1,round_to_100 = FALSE) {
    pct  <- prop.table(freq)
    var_name <- names(dimnames(freq))
    freq <- freq %>%
      stats::addmargins() %>%
      as.data.frame(row.names= names(dimnames(.)),
                    responseName = "freq",
                    stringsAsFactors = FALSE) %>%
      tibble::rownames_to_column("level") %>%
      dplyr::mutate(n   = ifelse(level=="Sum", freq, NA),
                    freq= ifelse(level=="Sum", NA, freq),
                    n   = ifelse(!is.na(n), formatC(n, format= "d", big.mark = ","), NA_character_),
                    freq= ifelse(!is.na(freq), formatC(freq, format= "d", big.mark = ","), NA_character_)
      ) %>%
      dplyr::select(level, n, freq)

    pct <- pct %>%
      as.data.frame(row.names= names(dimnames(.)),
                    responseName = "pct",
                    stringsAsFactors = FALSE) %>%
      tibble::rownames_to_column("level")  %>%
      dplyr::mutate(pct = if (round_to_100) formatC(exact_round_100(pct * 100,digits = pct_digits), digits = pct_digits, format = "f") else formatC(pct * 100, digits = pct_digits, format = "f"))%>%
      dplyr::select(level, pct)

    freq <- freq %>%
      dplyr::mutate_all(as.character)

    pct <- pct %>%
      dplyr::mutate_all(as.character)

    out <- dplyr::full_join(freq, pct, by = c("level")) %>%
      dplyr::mutate(stat= paste0(freq, " (", pct, "%)"),
                    stat= ifelse(level=="Sum", NA_character_, stat),
                    level= ifelse(level=="Sum", ".", level)) %>%
      dplyr::select(level, n, stat) %>%
      dplyr::mutate_all(as.character)

    out[match(c('.', levels(df[[var_name]])), out$level),]
  }

  output_two_way_tbl <- function(freq, pct_digits = 1,round_to_100 = FALSE) {
    tbl_var_name <- names(dimnames(freq))
    pct  <- prop.table(freq, margin = 2)

    # fisher exact test
    test <- try(stats::fisher.test(freq[rowSums(freq) != 0, ], hybrid = TRUE, conf.int = FALSE, simulate.p.value= TRUE, B= 9999), silent = TRUE)
    test <- if (inherits(test, "try-error")) NA else test$p.value

    # total
    total <- margin.table(freq, 2) %>%
      as.data.frame(responseName = "n", stringsAsFactors = FALSE) %>%
      dplyr::mutate(n= ifelse(!is.na(n), formatC(n, format= "d", big.mark = ","), NA_character_)) %>%
      reshape2::dcast(stats::as.formula( paste0(". ~ ", tbl_var_name[2])), value.var = "n") %>%
      dplyr::bind_cols(pval = format_pvalue(test),
               smd = format_smd(average_pairwise_smd(categorical_smd(t(freq))))) %>%
      dplyr::mutate(test = "Fisher")

    freq <- freq %>%
      as.data.frame(responseName = "freq", stringsAsFactors = FALSE) %>%
      dplyr::mutate(freq= ifelse(!is.na(freq), formatC(freq, format= "d", big.mark = ","), NA_character_))

    if(round_to_100){
      pct <- pct %>%
        as.data.frame(responseName = "pct", stringsAsFactors = FALSE) %>%
        dplyr::mutate(pct = ifelse(is.nan(pct),0,pct)) %>%
        dplyr::group_by(!!rlang::sym(tbl_var_name[2])) %>%
        dplyr::mutate(pct=  formatC(exact_round_100(pct * 100,digits = pct_digits), digits = pct_digits, format = "f"))


    }else {
      pct <- pct %>%
        as.data.frame(responseName = "pct", stringsAsFactors = FALSE) %>%
        dplyr::mutate(pct = ifelse(is.nan(pct),0,pct)) %>%
        dplyr::mutate(pct= formatC(pct*100, digits= pct_digits, format= "f"))
    }



    freq <- freq %>%
      dplyr::mutate_all(as.character)

    pct <- pct %>%
      dplyr::mutate_all(as.character)

    out <- dplyr::full_join(freq, pct, by= tbl_var_name) %>%
      dplyr::mutate(stat= paste0(freq, " (", pct, "%)")) %>%
      # dplyr::bind_rows(total) %>%
      dplyr::select(-freq, -pct) %>%
      reshape2::dcast(stats::as.formula(paste0(tbl_var_name, collapse= " ~ ")),
                      value.var = "stat") %>%
      dplyr::mutate_all(as.character)

    names(out)[1]<- names(total)[1]<- "level"
    out <- dplyr::full_join(total, out, by= "level", suffix= c("_n", "_stat"))
    out[match(c('.', levels(df[[tbl_var_name[1]]])), out$level),]
    # out
  }
  ##


  group <- rlang::enquo(group)

  # 1 - select variables of factor class
  if (rlang::quo_is_missing(group)) {
    df <- df %>%
      dplyr::ungroup() %>%
      dplyr::select_if(is.factor)

    fml <- make_univariate_fml(names(df))
    # 2 - create table object for ALL selected factor variables (not sure if it is a good idea but ...)
    # here we are going to drop unused levels (drop.unused.levels = TRUE)
    tbl_list <- lapply(fml, xtabs, data= df, addNA= includeNA, drop.unused.levels = drop.unused.levels)
    out     <- lapply(tbl_list, output_one_way_tbl, pct_digits = if (nrow(df)< 200) 0 else 1,round_to_100 = round_to_100)

  } else {
    df <- df %>%
      dplyr::group_by(!!group) %>%
      dplyr::select_if(is.factor)

    fml <- make_bivariate_fml(grep(paste0("^", rlang::quo_name(group), "$"), names(df), value= TRUE, invert = TRUE),
                              z= rlang::quo_name(group))

    # 2 - create table object for ALL selected factor variables (not sure if it is a good idea but ...)
    # here we are going to drop unused levels (drop.unused.levels = TRUE)
    tbl_list <- lapply(fml, xtabs, data= df, addNA= includeNA, drop.unused.levels = drop.unused.levels)
    out     <- lapply(tbl_list, output_two_way_tbl, pct_digits = if (nrow(df)< 200) 0 else 1,round_to_100 = round_to_100)
  }

  out <- out %>%
    dplyr::bind_rows(.id= "variable") %>%
    dplyr::mutate(level= ifelse(level==".", NA_character_, level))
  out

}



#---- summarize logical variables ----
#' @title logical_desp
#'
#' @details
#' An internal function that calculate frequencies and proportion of TRUE in logical variables. If there are more
#' than 1 group, then fisher exact tests are applied to assess the between-group differences.
#'
#' @param df Dataframe
#' @param group Optional grouping variable.
#' @return a dataframe consisting of columns of character variables indicating the frequency and proportion of logical variables.
logical_desp <- function(df, group) {

  binary_desp <- function(x, pct_digits= 1) {
    fun <- c(sum, mean)
    out <- sapply(fun,
                  function(f) {
                    res <- try(f(x, na.rm= TRUE), silent = TRUE)
                    res <- if (inherits(res, "try-error")) NA else res
                    return(res)
                  })

    freq <- formatC(out[1], format= "d", big.mark = ",")
    pct <- formatC(out[2]*100, digits= pct_digits, format= "f")
    pct <- paste0(pct, "%")
    out <- paste0(freq, " (", pct, ")")
    out
  }

  group <- rlang::enquo(group)
  df <- df %>%
    dplyr::ungroup()

  # fisher exact test
  # test<- try(stats::fisher.test(freq, hybrid = TRUE, conf.int = FALSE), silent = TRUE)
  # test<- if (class(test)=="try-error") NA else test$p.value
  test_fun <- fisher_test

  if (rlang::quo_is_missing(group)) {

    sum_stat <- df %>%
      dplyr::summarise_if(is.logical, dplyr::funs(binary_desp),
                          pct_digits= if (nrow(.)>= 200) 1 else 0) %>%
      tibble::rownames_to_column() %>%
      reshape2::melt(id.vars= "rowname", value.name = "stat") %>%
      dplyr::mutate(type= "freq") %>%
      dplyr::select(variable, type, stat)

    n_var <- df %>%
      dplyr::summarise_if(is.logical, dplyr::funs(n_avail)) %>%
      tibble::rownames_to_column() %>%
      reshape2::melt(id.vars= "rowname", value.name = "n") %>%
      dplyr::select(-rowname)

  } else {

    df <- df %>%
      # dplyr::ungroup() %>%
      dplyr::group_by(!!group)

    sum_stat <- df %>%
      dplyr::summarise_if(is.logical, dplyr::funs(binary_desp),
                          pct_digits= if (nrow(.)>= 200) 1 else 0) %>%
      reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE) %>%
      reshape2::dcast(stats::as.formula(paste("variable", rlang::quo_name(group), sep= " ~ "))) %>%
      dplyr::mutate(type= "freq") %>%
      # dplyr::left_join(test_fun(df, rlang::UQ(group)), by= c("variable", "type"))
      dplyr::left_join(test_fun(df, !!group), by= c("variable", "type")) %>%
      dplyr::left_join({
        smd <- lapply(df %>% dplyr::select_if(is.logical), function(x) {
          format_smd(average_pairwise_smd(continuous_smd(as.numeric(x), dplyr::pull(df, !!group), binary = TRUE)))
        })
        tibble::tibble(variable = names(smd), type = "freq", smd = unlist(smd))
      }, by = c("variable", "type"))

    n_var <- df %>%
      dplyr::summarise_if(is.logical, dplyr::funs(n_avail)) %>%
      reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE) %>%
      reshape2::dcast(stats::as.formula(paste("variable", rlang::quo_name(group), sep= " ~ ")))
  }

  n_var <- n_var %>%
    dplyr::mutate_all(as.character)

  sum_stat <- sum_stat %>%
    dplyr::mutate_all(as.character)

  dplyr::left_join(n_var, sum_stat, by= "variable", suffix= c("_n", "_stat")) %>%
    dplyr::select(variable, type, dplyr::everything()) %>%
    dplyr::mutate(type= NA_character_) %>%
    dplyr::arrange(variable, type)
}


#' @title fisher_test
#'
#' @details
#' An internal function that applies fisher exact tests to assess the between-group differences in logical variables
#'
#' @param df Dataframe
#' @param group Grouping variable used for the test.
#' @return a dataframe of a single column of character variables indicating p-values.
fisher_test <- function(df, group) {

  group <- rlang::enquo(group)
  df <- df %>%
    dplyr::ungroup() %>%
    dplyr::group_by(!!group)

  # fisher_test<- function(...) try(stats::fisher.test(..., hybrid = TRUE, conf.int= FALSE), silent = TRUE)
  fisher_test <- if (dplyr::n_groups(df)==2) {
    function(...) try(stats::fisher.test(..., conf.int= FALSE), silent = TRUE)
  } else {
    function(...) try(stats::fisher.test(..., hybrid = TRUE, conf.int= FALSE), silent = TRUE)
  }

  df %>%
    dplyr::select_if(is.logical) %>%
    reshape2::melt(id.vars= rlang::quo_name(group),
                   factorsAsStrings= TRUE,
                   na.rm= TRUE) %>%
    dplyr::group_by(variable) %>%
    tidyr::nest() %>%
    dplyr::mutate(freq= purrr::map(data,
                                   function(df) {

                                     res<- df %>%
                                       table() %>%
                                       fisher_test()

                                     # res<- if (class(res)=="try-error") NA else res$p.value
                                     res<- if (inherits(res, "try-error")) {
                                       fisher_test<- if (dplyr::n_groups(df)==2) {
                                         function(...) try(stats::fisher.test(..., conf.int= FALSE, simulate.p.value = TRUE, B=5000), silent = TRUE)
                                       } else {
                                         function(...) try(stats::fisher.test(..., hybrid = TRUE, conf.int= FALSE, simulate.p.value = TRUE, B=5000), silent = TRUE)
                                       }
                                       res_try<- df %>%
                                         table() %>%
                                         fisher_test()
                                       if (inherits(res_try, "try-error")) NA else res_try$p.value
                                     } else res$p.value
                                     res
                                   })) %>%
    dplyr::select(-data) %>%
    tidyr::unnest() %>%
    reshape2::melt(id.vars= "variable", variable.name= "type", value.name = "pval") %>%
    dplyr::mutate(pval= format_pvalue(pval)) %>%
    dplyr::mutate_all(as.character) %>% dplyr::mutate(test = "Fisher")

  #   variable  type       pval
  # 1       dm  freq 0.04608804
  # 2       af  freq 0.19948767
}




#---- summarize numeric variables ----
#' @title numeric_desp
#'
#' @details
#' An internal function that report mean, standard deviation, median and interquartile range by group.
#'
#' @param df Dataframe
#' @param group Optional grouping variable.
#' @return a dataframe consisting of columns of character variables.
numeric_desp <- function(df, group) {
  group <- rlang::enquo(group)
  df <- df %>%
    dplyr::ungroup()

  if (rlang::quo_is_missing(group)) {

    df <- df %>%
      dplyr::select_if(is.numeric)

    n_var <- df %>%
      dplyr::summarise_if(is.numeric, list(~ n_avail(.))) %>%
      tibble::rownames_to_column() %>%
      reshape2::melt(id.vars= "rowname", value.name = "n") %>%
      dplyr::select(-rowname)

    sum_stat <- if (ncol(df)==1) {
      # the naming rule changes when there is only one numeric variable
      df %>%
        dplyr::summarise_if(is.numeric, list(~ mean_sd(.), ~ med_iqr(.))) %>%
        dplyr::rename_at(dplyr::vars(mean_sd, med_iqr),
                         function(x) paste(names(df), x, sep= "_")) %>%
        tibble::rownames_to_column() %>%
        reshape2::melt(id.vars = "rowname", value.name = "stat") %>%
        dplyr::mutate(type = ifelse(grepl("mean_sd$", variable), "meansd", "mediqr"),
                      variable = gsub("(_mean_sd|_med_iqr)$", "", variable)) %>%
        dplyr::select(variable, type, stat)

    } else {
      df %>%
        dplyr::summarise_if(is.numeric, list(~ mean_sd(.), ~ med_iqr(.))) %>%
        tibble::rownames_to_column() %>%
        reshape2::melt(id.vars = "rowname", value.name = "stat") %>%
        dplyr::mutate(type = ifelse(grepl("mean_sd$", variable), "meansd", "mediqr"),
                      variable = gsub("(_mean_sd|_med_iqr)$", "", variable)) %>%
        dplyr::select(variable, type, stat)

    }

  } else {

    df <- df %>%
      dplyr::group_by(!!group) %>%
      dplyr::select_if(is.numeric)

    n_var <- df %>%
      dplyr::summarise_if(is.numeric, list(~ n_avail(.))) %>%
      reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE) %>%
      reshape2::dcast(stats::as.formula(paste("variable", rlang::quo_name(group), sep= " ~ ")))

    sum_stat <- if (length(grep(dplyr::group_vars(df), names(df), invert = TRUE))==1) {
      df %>%
        dplyr::summarise_if(is.numeric, list(~ mean_sd(.), ~ med_iqr(.))) %>%
        dplyr::rename_at(dplyr::vars(mean_sd, med_iqr),
                         function(x) paste(grep(dplyr::group_vars(df), names(df), invert = TRUE, value= TRUE), x, sep= "_")) %>%
        reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE) %>%
        reshape2::dcast(stats::as.formula(paste("variable", rlang::quo_name(group), sep= " ~ "))) %>%
        dplyr::mutate(type= ifelse(grepl("mean_sd$", variable), "meansd", "mediqr"),
                      variable= gsub("(_mean_sd|_med_iqr)$", "", variable))
    } else {
      df %>%
        dplyr::summarise_if(is.numeric, list(~ mean_sd(.), ~ med_iqr(.))) %>%
        reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE) %>%
        reshape2::dcast(stats::as.formula(paste("variable", rlang::quo_name(group), sep= " ~ "))) %>%
        dplyr::mutate(type= ifelse(grepl("mean_sd$", variable), "meansd", "mediqr"),
                      variable= gsub("(_mean_sd|_med_iqr)$", "", variable))
    }

    if (dplyr::n_groups(df) > 1) {
      test_fun <- if (dplyr::n_groups(df)==2) two_sample_test else k_sample_test
      sum_stat <- sum_stat %>%
        dplyr::left_join(test_fun(df, !!group), by= c("variable", "type"))

      smd <- df %>%
        dplyr::ungroup() %>%
        dplyr::select_if(is.numeric) %>%
        lapply(function(x) format_smd(average_pairwise_smd(continuous_smd(x, dplyr::pull(df, !!group))))) %>%
        unlist()
      sum_stat <- sum_stat %>%
        dplyr::left_join(tibble::tibble(variable = names(smd), smd = smd), by = "variable")
    } else {
      sum_stat <- sum_stat %>% dplyr::mutate(smd = NA_character_)
    }

  }

  n_var <- n_var %>%
    dplyr::mutate_all(as.character)

  sum_stat <- sum_stat %>%
    dplyr::mutate_all(as.character)

  dplyr::left_join(n_var, sum_stat, by= "variable", suffix= c("_n", "_stat")) %>%
    dplyr::select(variable, type, dplyr::everything()) %>%
    dplyr::arrange(variable, type)
}



#' @title n_avail
#'
#' @details
#' An internal function that format the number of non-missing observations in a variable
#'
#' @param x Numeric variable
#' @return a character reporting the number of non-missing observations
n_avail <- function(x) formatC( sum( !is.na(x) ), digits= 0, format= "d", big.mark = ",")

#' @title mean_sd
#'
#' @details An internal function that format mean and standard deviation of a continuous variable
#'
#' @param x Numeric variable
#' @return a character reporting the mean plus/minus standard deviation
mean_sd <- function(x) {
  n_dec <- decimalplaces(x)

  funs <- c(mean, stats::sd)
  out <- sapply(funs,
               function(f) {
                 res<- try(f(x, na.rm= TRUE), silent = TRUE)
                 res<- if (inherits(res, "try-error")) NA else res
                 return(res)
               })

  if (length(x[!is.na(x)])==0) {
    out <- "---"
  } else if (length(x[!is.na(x)])==1) {
    out <- formatC( out[1], digits= n_dec, format= "f", big.mark = ",", flag= "#")
  } else {
    out <- formatC( out, digits= n_dec, format= "f", big.mark = ",", flag= "#")
    out <- paste0(out, collapse = " \u00B1 ") # plusminus sign
  }

  out <- c(stat= out)
  out
}



#' @title med_iqr
#'
#' @details An internal function that format median and interquartile range of a continuous variable
#'
#' @param x Numeric variable
#' @return a character reporting the median (Q1 - Q3)

med_iqr <- function(x) {
  q1 <- function(x, ...) stats::quantile(x, probs = .25, ...)
  q3 <- function(x, ...) stats::quantile(x, probs = .75, ...)

  n_dec<- decimalplaces(x)
  funs<- c(stats::median, q1, q3)
  out<- sapply(funs,
               function(f) {
                 res <- try(f(x, na.rm= TRUE), silent = TRUE)
                 res <- if (inherits(res, "try-error")) NA else res
                 return(res)
               })
  if (length(x[!is.na(x)])==0) {
    out<- "---"
  } else if (length(x[!is.na(x)])==1) {
    out<- formatC( out[1], digits= n_dec, format= "f", big.mark = ",", flag= "#")
  } else {
    out<- formatC( out, digits= n_dec, format= "f", big.mark = ",", flag= "#")
    out<- paste0(out[1], " (",
                 paste0(out[-1], collapse= " \u2013 "), ")") # long dash
  }

  out<- c(stat= out)
  out
}



#---- test ----
#' @title two_sample_test
#'
#' @details
#' An internal function that tests equality of location parameter using two sample t-tests with unequal
#' variance when mean is reported and nonparametric rank-sum tests otherwise in comparing of two groups.
#'
#' @param df Data frame containing the numeric variables.
#' @param group Factor grouping variable.
#' @return a 2-tuple vectors reporting p-values

two_sample_test <- function(df, group) {

  group <- rlang::enquo(group)

  df %>%
    dplyr::ungroup() %>%
    # dplyr::group_by(rlang::UQ(group)) %>%
    dplyr::group_by(!!group) %>%
    dplyr::select_if(is.numeric) %>%
    reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE, na.rm= TRUE) %>%
    dplyr::group_by(variable) %>%
    tidyr::nest() %>%
    dplyr::mutate(ttest= purrr::map_dbl(data,
                                        function(df) {
                                          fml<- stats::as.formula(paste0("value ~ factor(", rlang::quo_name(group), ")"))
                                          res<- try(stats::t.test(fml, data= df, var.equal = FALSE), silent = FALSE)
                                          if (inherits(res, "try-error")) NA_real_ else res$p.value
                                        }),
                  wilcox= purrr::map_dbl(data,
                                         function(df) {
                                           # if (!is.factor(df[rlang::quo_name(group)])) df[rlang::quo_name(group)]<- factor(df[rlang::quo_name(group)])
                                           fml<- stats::as.formula(paste0("value ~ factor(", rlang::quo_name(group), ")"))
                                           res<- try(stats::wilcox.test(fml, data= df), silent = FALSE)
                                           if (inherits(res, "try-error")) NA_real_ else res$p.value
                                         })) %>%
    dplyr::select(-data) %>%
    # tidyr::unnest(cols = c(ttest, wilcox)) %>%
    reshape2::melt(id.vars= "variable", variable.name= "test", value.name = "pval") %>%
    dplyr::mutate(type= ifelse(grepl("^ttest", test), "meansd", "mediqr"),
                  pval= format_pvalue(pval)
    ) %>%
    dplyr::mutate_all(as.character)
}



#' @title k_sample_test
#'
#' @details An internal function that tests equality of location parameter using one way ANOVA with unequal
#' variance when mean is reported and nonparametric Kruskal-Wallis tests otherwise in comparing >2 groups.
#'
#' @param df Data frame containing the numeric variables.
#' @param group Factor grouping variable.
#' @return a 2-tuple vectors reporting p-values

k_sample_test <- function(df, group) {

  group <- rlang::enquo(group)

  df %>%
    dplyr::ungroup() %>%
    dplyr::group_by(!!group) %>%
    dplyr::select_if(is.numeric) %>%
    reshape2::melt(id.vars= rlang::quo_name(group), factorsAsStrings= TRUE, na.rm= TRUE) %>%
    dplyr::group_by(variable) %>%
    tidyr::nest() %>%
    dplyr::mutate(oneway= purrr::map_dbl(data,
                                         function(df) {
                                           fml<- stats::as.formula(paste0("value ~ factor(", rlang::quo_name(group), ")"))
                                           res<- try(stats::oneway.test(fml, data= df, var.equal = FALSE), silent = FALSE)
                                          if (inherits(res, "try-error")) NA_real_ else res$p.value
                                         }),
                  kruskal= purrr::map_dbl(data,
                                          function(df) {
                                            fml<- stats::as.formula(paste0("value ~ factor(", rlang::quo_name(group), ")"))
                                            res<- try(stats::kruskal.test(fml, data= df), silent = FALSE)
                                            if (inherits(res, "try-error")) NA_real_ else res$p.value
                                          })) %>%
    dplyr::select(-data) %>%
    # tidyr::unnest(cols = c(ttest, wilcox)) %>%
    reshape2::melt(id.vars= "variable", variable.name= "test", value.name = "pval") %>%
    dplyr::mutate(type= ifelse(grepl("^oneway", test), "meansd", "mediqr"),
                  pval= format_pvalue(pval)
    ) %>%
    dplyr::mutate_all(as.character)
}



#' @title Round a Vector of Percentages to 100
#'
#' @description Rounds a vector of values to a 100% value using the largest remainder method
#'
#' @param values A numeric vector of percentages that should approximately sum to 100
#' @param digits An integer indicating the number of decimal places to round to. Default is 1 (whole numbers).
#'
#' @return A numeric vector of the same length as `values`, rounded to the specified number of digits, and summing to exactly 100.


exact_round_100 <- function(values,digits = 1){
  # Based on the internalRoundFixedSum  from the nbc4va package but adding the option to round to select number of digits

  scaleFactor <- 10^digits
  values_scaled <- values * scaleFactor

  #If the total is already 100 no need to apply any rounding
  if (all(values_scaled%%1 == 0)) {
    out <- values_scaled
  }
  else {
    floor_values_scaled <- floor(values_scaled)
    difference <-  values_scaled - floor_values_scaled

    remainder <- 100*scaleFactor - sum(floor_values_scaled)
    i <- utils::tail(order(difference), remainder)
    floor_values_scaled[i] <- floor_values_scaled[i] + 1
    out <- floor_values_scaled
  }
  return(out/scaleFactor)

}


#' @title recode_missing
#'
#' @param x A vector in which coded missing values should be replaced.
#' @param na.value Values to replace with \code{NA}.
#' @details
#' An internal function that replace missing value code with NA.
#'
#' @return input variable with NA
recode_missing <- function(x, na.value= NULL) {
  x[x %in% na.value]<- NA
  x
}
