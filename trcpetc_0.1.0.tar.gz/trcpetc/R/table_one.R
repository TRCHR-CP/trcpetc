



#' @title table_one
#'
#' @description
#' Generates a table of summary statistics for descriptive analysis.
#'
#' @details
#' The \code{table_one} function computes summary statistics for continuous, logical, and factor variables,
#' following the statistical reporting guidelines of the \emph{Annals of Medicine}. If a grouping variable is provided,
#' the function can also evaluate between-group differences. The input data frame should consist only of numeric,
#' logical, and factor variables. Factor variables with only two levels should be converted to logical variables.
#' Date and datetime variables should be excluded. Used with \code{\link{kable_table_one}} to output a kable report ready table.
#'See also \code{\link{check_box_convert}} and \code{\link{factor_order}} for data pre-processing functions.
#'
#' @param df A data frame consisting of numeric, logical, and factor variables with or without a grouping variable.
#' @param group Name of the grouping variable (optional).
#' @param datadic A data frame serving as a data dictionary, containing variable names and their descriptions.
#' @param var_name The column name of \code{datadic} that contains the variable names. Only required if the column name is not \code{"var_name"}.
#' @param var_desp The column name of \code{datadic} that contains the variable descriptions. Only required if the column name is not \code{"var_desp"}.
#' @param seed An optional seed value for reproducibility of p-values.
#' @param include_overall Character string specifying whether and how to include an overall summary.
#'   Must be one of:
#'   \itemize{
#'     \item \code{"none"}: Do not include an overall summary (default).
#'     \item \code{"group"}: Include an overall summary only for observations with non-missing values in the grouping variable.
#'     \item \code{"all"}: Include an overall summary for all observations, regardless of missingness in the grouping variable.
#'   }
#'   Default is \code{"none"}.
#' @param total Logical; whether to report the total N. Default is \code{TRUE}.
#' @param pval Logical; deprecated compatibility option. Use \code{stat_test} instead. \code{TRUE} selects p-values and \code{FALSE} suppresses between-group statistics.
#' @param stat_test Character string specifying the between-group statistic to report. One of \code{"smd"} (the default), \code{"pval"}, or \code{"none"}. SMDs use pooled within-group variance for numeric and logical variables and a generalized Mahalanobis distance of multinomial proportions for factors.
#' @param print_test Logical. If \code{TRUE}, the output will include the type of statistical test applied to each variable. Default is \code{FALSE}.
#' @param continuous Character string specifying the summary statistics for continuous variables.
#'   Must be one of:
#'   \itemize{
#'     \item \code{"mediqr"}: Median and interquartile range.
#'     \item \code{"meansd"}: Mean and standard deviation.
#'     \item \code{c("mediqr","meansd")}: Both median/IQR and mean/SD.
#'   }
#' @param round_to_100 Logical; force rounded total to add up to 100 using the largest remainder method for factor variables.
#' @param drop.unused.levels Logical; removes factor levels with zero counts. Levels with zero are not included in statistical tests.
#' @param overall_label Character string to label the overall summary column. Default is \code{"Overall"}.
#' @param include_Missing Logical; whether to include missing value counts in the summary. Default is \code{FALSE}.
#' @param Check_box Optional character vector of variable names from a checkbox-style question. In the output table, these variables will be displayed together as levels of a single item, but each level will be analyzed independently with its own statistical test.
#' @param Check_box_title Optional character string to identify the checkbox column titles.
#' @param print_unused Logical; whether to print variables that were excluded due to unsupported types. Default is \code{FALSE}.
#'
#' @return A data frame containing summary statistics by variable type, optionally stratified by group.
#'
#' @examples
#' library(dplyr)
#' Comorbidities  <- cardio_data %>% select(Diabetes:NoComorbidities) %>% names()
#'
#'work_d <- cardio_data %>%
#'  mutate(SurgeryType = factor_order(SurgeryType)) %>%
#'  check_box_convert(check_box_cols = Comorbidities,title = "Comorbidities¹")
#'
#'
#'
#'demo_table <-  table_one(df = work_d ,
#'          group = Sex,
#'         datadic = cardio_data_dictionary %>%
#'            rbind(data.frame("VariableName" = "Comorbidities¹",
#'                             "Label" ="Comorbidities¹", "Description"= "All Comorbidities")),
#'         var_name = VariableName,
#'          var_desp = Label,
#'          include_overall = "all",
#'          Check_box = Comorbidities,
#'          Check_box_title = "Comorbidities¹")
#'
#'
#'  # Creating a report ready kable output
#'  options(knitr.kable.NA = '')
#'  kable_table_one(demo_table,caption =  "Summary table overall and stratified by sex") %>%
#'  kableExtra::footnote(
#'    general = "¹Patients could present with more than one comorbidity, totals may not sum to 100%.",
#'    general_title = "",
#'    footnote_as_chunk = TRUE)
#'
#' @export
#' @importFrom magrittr %>%
#' @importFrom data.table :=


table_one <- function(df, group, datadic = NULL, var_name, var_desp, seed = 123, include_overall  = c("none","group","all"),
                      total = TRUE,pval = NULL,print_test  = FALSE,continuous = "mediqr",round_to_100 = FALSE,
                      drop.unused.levels = FALSE,overall_label = "Overall",include_Missing = FALSE,
                      Check_box = NULL,Check_box_title = NULL,print_unused = FALSE,
                      stat_test = c("smd", "pval", "none")) {

  set.seed(seed)




  # Setting up  -------------------------------------------------------------------------


  include_overall <- match.arg(include_overall)
  op <- options(warn = -1)
  on.exit(options(op))

  group <- rlang::enquo(group)
  var_name <- rlang::enquo(var_name)
  var_desp <- rlang::enquo(var_desp)

  if (rlang::quo_is_missing(var_name)) var_name <- rlang::quo(var_name)
  if (rlang::quo_is_missing(var_desp)) var_desp <- rlang::quo(var_desp)

  stat_test <- match.arg(stat_test)
  if (!is.null(pval)) {
    if (!is.logical(pval) || length(pval) != 1 || is.na(pval)) {
      stop("`pval` must be TRUE or FALSE when supplied.")
    }
    stat_test <- if (pval) "pval" else "none"
    warning("`pval` is deprecated; use `stat_test = \"pval\"` or `stat_test = \"none\"`.", call. = FALSE)
  }
  if (rlang::quo_is_missing(group)) stat_test <- "none"
  if (stat_test != "pval") print_test <- FALSE

  # Errors -------------------------------------------------------------------------

  ## Only allows mediqr & meansd for continuous variables

  invalid_continuous <- continuous[!continuous %in% c("mediqr", "meansd")]
  if (length(invalid_continuous) > 0) {
    stop(paste0('Invalid value(s) in "continuous": ', paste(unique(invalid_continuous), collapse = ", "),
                '. Allowed values are "mediqr" and "meansd".'))
  }

  #Overall name can not match a group name
  if((!rlang::quo_is_missing(group) & include_overall %in% c("group","all"))){
    if(overall_label %in% (df %>% dplyr::pull(!!group) %>% unique() %>% stats::na.omit())){
      stop(paste0("`overall_label` ('", overall_label, "') cannot match an existing level in the grouping variable `"))
    }

  }

  if(print_unused){

    print(paste(
      "Unused columns include:",
      paste0(
        df %>%
          dplyr::ungroup() %>%
          dplyr::select_if(~ is.character(.) || lubridate::is.Date(.)) %>%
          colnames(),
        collapse = ", "
      )))

  }






  #Grouped summary table -------------------------------------------------------------------------

  if(!rlang::quo_is_missing(group)){
    summary_group <- table_one_stratify(df,group = !!group,total = total,round_to_100 = round_to_100,drop.unused.levels = drop.unused.levels)


    # Including a missing column and p-value -------------------------------------------------------------------------


    if(include_Missing){
      summary_group_missing <- df %>% dplyr::mutate(
        {{ group }} := forcats::fct_explicit_na({{ group }}, na_level = "Missing")) %>%
        table_one_stratify(group = !!group,total = total,round_to_100 = round_to_100,drop.unused.levels = drop.unused.levels)
      summary_group <- if (stat_test == "none") {
        summary_group_missing
      } else {
        summary_group_missing %>%
          dplyr::left_join((summary_group %>% dplyr::select(row_id, dplyr::all_of(stat_test))),by = c('row_id'),suffix = c(".Missing",".No.Missing"))
      }

    }

  }


  # Overall summary table -------------------------------------------------------------------------

  ##If include overall = "group" remove rows where the grouping variable is missing
  if(!rlang::quo_is_missing(group) & include_overall == "group"){
    df <- df %>% dplyr::filter(!is.na(!!group))
  }


  ##Remove the grouping variable from the overall table
  if(!rlang::quo_is_missing(group)){
    df <- df %>% dplyr::select(-!!group)
  }

  if(rlang::quo_is_missing(group) |include_overall == "all" | include_overall == "group" ){
    summary_overall <- table_one_overall(df,total = total,round_to_100 = round_to_100,overall_label = overall_label,drop.unused.levels = drop.unused.levels)
  }


  # Combining summary tables together -------------------------------------------------------------------------

  if(!rlang::quo_is_missing(group) & (include_overall == "all" | include_overall == "group" )){
    summary <- summary_overall %>% dplyr::left_join(summary_group,by = c('row_id','variable','type'))
  }else if(rlang::quo_is_missing(group)){
    summary <- summary_overall
  }else {
    summary <- summary_group
  }

  ##Run the grouped table (If include_overall is include_overall = all or include_overall = group)


  # Removing pre-defined columns (pval, continuous) -------------------------



  if (stat_test != "pval") summary$pval = summary$pval.Missing = summary$pval.No.Missing <- NULL
  if (stat_test != "smd") summary$smd = summary$smd.Missing = summary$smd.No.Missing <- NULL
  if(!print_test) summary$test  <- NULL

  #Optionally removing the continuous variables
  if(!"meansd" %in% (continuous)) summary <- summary %>% dplyr::filter(!grepl("_meansd$", row_id))
  if(!"mediqr" %in% (continuous)) summary <- summary %>% dplyr::filter(!grepl("_mediqr$", row_id))


  # Adding the datadic and cleaning the table -------------------------------------------------------------------------


  if (is.null(datadic)) {
    out <- summary %>%
      dplyr::select(row_id, variable, type,
                    dplyr::ends_with("n"), dplyr::ends_with("stat"), dplyr::everything()) %>%
      # dplyr::select(-!!var_desp) %>%
      dplyr::mutate(type = ifelse(is.na(type) & row_id==variable,
                                  gsub("(^[[:lower:]])", "\\U\\1", variable, perl=TRUE), type),
                    type = ifelse(type %in% c("meansd", "mediqr"),
                                  gsub("(^[[:lower:]])", "\\U\\1", variable, perl=TRUE), type),
                    type = ifelse(row_id==paste0(variable, "TRUE"),
                                  gsub("(^[[:lower:]])", "\\U\\1", variable, perl=TRUE), type)) %>%
      dplyr::rename(`var_desp`= type)
  } else {
    out <- summary %>%
      dplyr::left_join(dplyr::select(datadic, !!var_name, !!var_desp),
                       by = c("variable"= rlang::quo_name(var_name))) %>%
      dplyr::mutate(type = ifelse(is.na(type) & row_id==variable, !!var_desp, type), # factor
                    type = ifelse(type %in% c("meansd", "mediqr"), !!var_desp, type), # continuous
                    type = ifelse(row_id==paste0(variable, "TRUE"), !!var_desp, type), # logical
      ) %>%
      dplyr::select(row_id, variable, type,
                    dplyr::ends_with("n"), dplyr::ends_with("stat"), dplyr::everything()) %>%
      dplyr::select(-!!var_desp) %>%
      dplyr::rename(`var_desp`= type)
  }

  ##Formatting check box rows to indent
  out <- out   %>%
    dplyr::mutate(dplyr::across(
      dplyr::ends_with("_n"),
      ~ dplyr::if_else(variable %in% Check_box, NA_character_, .)
    ))

  ##Formatting title rows to
  out <- out   %>%
    dplyr::mutate(dplyr::across(
      dplyr::matches("(_stat$|^pval$)"),
      ~ dplyr::if_else(variable %in% Check_box_title, NA_character_, .)
    ))


    list(tab = out, pval = stat_test == "pval", stat_test = stat_test,
      include_Missing = include_Missing, print_test = print_test, total=total)


}



# Kable table one  -------------------------------------------------------------------------


#' @title kable_table_one
#' @description Produces a report ready \code{kable} table from a \code{\link{table_one}} obj
#'
#' @param tableone A \code{table_one} object created by the \code{\link{table_one}} function..
#' @param caption Optional character string providing a table caption.
#' @param bold_variables Logical; if \code{TRUE}, variable names are displayed in bold. Default is \code{TRUE}.
#' @param full_width Logical;  Controls whether the output table spans the full page width. Default is \code{TRUE}

#' @examples
#' library(dplyr)
#' Comorbidities  <- cardio_data %>% select(Diabetes:NoComorbidities) %>% names()
#'
#'work_d <- cardio_data %>%
#'  mutate(SurgeryType = factor_order(SurgeryType)) %>%
#'  check_box_convert(check_box_cols = Comorbidities,title = "Comorbidities¹")
#'
#'
#'
#'demo_table <-  table_one(df = work_d ,
#'          group = Sex,
#'         datadic = cardio_data_dictionary %>%
#'            rbind(data.frame("VariableName" = "Comorbidities¹",
#'                             "Label" ="Comorbidities¹", "Description"= "All Comorbidities")),
#'         var_name = VariableName,
#'          var_desp = Label,
#'          include_overall = "all",
#'          Check_box = Comorbidities,
#'          Check_box_title = "Comorbidities¹")
#'
#'
#'  # Creating a report ready kable output
#'  options(knitr.kable.NA = '')
#'  kable_table_one(demo_table,caption =  "Summary table overall and stratified by sex") %>%
#'  kableExtra::footnote(
#'    general = "¹Patients could present with more than one comorbidity, totals may not sum to 100%.",
#'    general_title = "",
#'    footnote_as_chunk = TRUE)
#' @importFrom magrittr %>%
#' @export

kable_table_one <- function(tableone,caption = "", bold_variables = TRUE,full_width = TRUE){

  out = tableone$tab
  pval = tableone$pval
  stat_test = if (!is.null(tableone$stat_test)) tableone$stat_test else if (pval) "pval" else "none"
  include_Missing=tableone$include_Missing
  total = tableone$total
  print_test = tableone$print_test


  indent <-  out %>% dplyr::filter(row_id != "Total_N") %>%
    dplyr::mutate(row_number = dplyr::row_number()) %>%
    dplyr::select(dplyr::matches("_n$"),row_number)  %>%
    dplyr::filter(rowSums(is.na(.)) == (ncol(.)-1)) %>%
    dplyr::pull(row_number)


  first_row <- out %>% utils::head(1)  %>%
    dplyr::select(dplyr::ends_with("_n"))

  variable_names <- gsub("_n", "", names(first_row))
  n_columns <- paste0(variable_names, "_n")
  stat_columns <- paste0(variable_names, "_stat")

  headers <- if(total){
    paste0(variable_names," (N = ",first_row,")")} else{
      variable_names
    }

  out <- out %>%
    dplyr::mutate(bold = bold_variables) %>%
    dplyr::filter(!(dplyr::row_number() == 1 & total == TRUE))  %>%
    dplyr::mutate(var_desp = ifelse(
      (!seq_along(var_desp) %in% indent) & bold,
      kableExtra::cell_spec(var_desp, bold = TRUE),
      var_desp)) %>%
      dplyr::mutate(
    dplyr::across(
      dplyr::any_of(c("pval", "pval.No.Missing", "pval.Missing")),
      ~ gsub("<", "&lt;", .)
    )
  ) %>%
    dplyr::select(
      dplyr::all_of(c("var_desp", c(rbind(n_columns, stat_columns)))),
      dplyr::any_of(if (stat_test == "pval") c("pval", "pval.No.Missing", "pval.Missing") else
            if (stat_test == "smd") c("smd", "smd.No.Missing", "smd.Missing") else NULL),
      dplyr::any_of(if (print_test) "test" else NULL)
    ) %>%

    kableExtra::kbl(caption = caption,
                    booktabs=TRUE,
                    escape = FALSE,
                    align= c('l', rep(c('c', 'c'), length(headers)), 'r'),
                    col.names = c('Variables', rep(c('N', 'Stat'), length(headers)),
                                  if (stat_test == "pval" & !include_Missing) '*P*-value' else character(0) ,
                                  if (stat_test == "pval" & include_Missing) 'Without missing' else character(0) ,
                                  if (stat_test == "pval" & include_Missing) 'With missing' else character(0) ,
                                  if (stat_test == "smd" & !include_Missing) 'SMD' else character(0),
                                  if (stat_test == "smd" & include_Missing) 'Without missing' else character(0),
                                  if (stat_test == "smd" & include_Missing) 'With missing' else character(0),
                                  if (print_test) 'Statistical test' else character(0))) %>%
    kableExtra::row_spec(row = 0, align = "c") %>%
    kableExtra::kable_styling(bootstrap_options = c("striped", "hover", "condensed"),
                              full_width = full_width) %>%
    kableExtra::add_header_above(c("", stats::setNames (rep(2, length(headers)), headers),
                    if (stat_test == "pval" & !include_Missing) '' else character(0),
                    if (stat_test == "pval" & include_Missing) stats::setNames (rep(2, 1), "*P*-value") else character(0),
                    if (stat_test == "smd" & !include_Missing) '' else character(0),
                    if (stat_test == "smd" & include_Missing) stats::setNames (rep(2, 1), "SMD") else character(0),
                    if (print_test ) '' else character(0)))%>%
    kableExtra::add_indent(indent)

  out
}


